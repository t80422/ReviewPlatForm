--�ɧU�ӽЭק����W�� s_review > s_review_fst
exec sp_rename 'dbo.subsidy.s_review','s_review_fst','COLUMN';

--�s�W�ɧU�ӽФ��f�����
alter table subsidy add s_review_application nvarchar(100);
alter table subsidy add s_review_insur_member nvarchar(100);
alter table subsidy add s_review_emp_lst nvarchar(100);
alter table subsidy add s_review_applicants nvarchar(100);
alter table subsidy add s_review_else nvarchar(100);
alter table subsidy add s_review_else2 nvarchar(100);
alter table subsidy add s_review_else3 nvarchar(100);
alter table subsidy add s_approved_amount int;
alter table subsidy add s_mg_id_association int;

--�s�W�H�����f�����
alter table member add mb_review_contract nvarchar(100);
alter table member add mb_review_income_certificate nvarchar(100);

--�s�W�H���f�����
alter table member add mb_review nvarchar(100);

--�s�Wtable:employment_insurance
create table employment_insurance(	
ei_year int,
ei_month int,
ei_no int,
ei_name nvarchar(100),
ei_id_card nvarchar(100),
ei_birthday nvarchar(100),
ei_type nvarchar(100),
ei_last_change_date nvarchar(100),
ei_memo nvarchar(100),
ei_enter_month int,
constraint PK_employment_insurance primary key (ei_year,ei_month,ei_id_card)
);

--�s�Wtable:subsidy_review
create table subsidy_review(
	sr_id int identity(1,1) primary key,
	sr_s_id int,
	sr_date date,
	sr_time time(0),
	sr_reviewer nvarchar(100),
	sr_application_amount int,
	sr_review_application nvarchar(100),
	sr_review_insur_member nvarchar(100),
	sr_review_emp_lst nvarchar(100),
	sr_review_applicants nvarchar(100),
	sr_review_else nvarchar(100),
	sr_review_else2 nvarchar(100),
	sr_review_else3 nvarchar(100),
);

--�s�W�ɧU�ӽФH�����
alter table subsidy_member add sm_approved_amount int;
alter table subsidy_member add sm_mg_id_association int;
alter table subsidy_member add sm_review_income_certificate nvarchar(100);
alter table subsidy_member add sm_qualifications bit;
alter table subsidy_member add sm_calculation int;

--�s�Wtable:subsidy_member_review
create table subsidy_member_review
(
	smr_id int identity(1,1) primary key,
	smr_sm_id int,
	smr_date date,
	smr_time time(0),
	smr_reviewer nvarchar(100),
	smr_approved_amount int,
	smr_review_contract nvarchar(100),
	smr_review_income_certificate nvarchar(100),
	smr_reveiw_status nvarchar(100),
);

--�s�W�ȱJ�~�����
alter table industry add id_mg_id_association int;